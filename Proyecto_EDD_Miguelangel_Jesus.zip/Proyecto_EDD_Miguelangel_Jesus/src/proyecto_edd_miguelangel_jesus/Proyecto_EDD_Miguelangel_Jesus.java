/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package proyecto_edd_miguelangel_jesus;

import Interfaces.Inicio;

/**
 *
 * 
 * Esta clase tan solo sirve para inicializar el proyecto 
 * 
 * @author Miguel
 *@version: 9/03/2025/A  
 */
public class Proyecto_EDD_Miguelangel_Jesus {

    /**
     * 
     * 
     * 
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Una funcion estatica que sirve para simplemente ir a la intterfaz de inicio
        Inicio v1 = new Inicio();
    }
    
}
